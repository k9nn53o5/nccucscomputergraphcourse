#include "swgl.h"

GLdouble CTM_MV[16];	//Current Transformation Matrix: ModelView
GLdouble CTM_P[16];		//Current Transformation Matrix: Projection
GLdouble *CTM;			//Pointer to Current Transformation Matrix

//h: input the vertex in world space(h)
//w: vertex in windows space(w)
bool swTransformation(const GLdouble h[4], GLdouble w[4])
{
	//p = CTM_P*CTM_MV*h


	//prespective division


	//viewport transformation



	return true;
}
